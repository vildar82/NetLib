﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace WpfApp1
{
    public class ColorNCS
    {
        public string Article { get; set; }
        public Color Color { get; set; }
        public Brush ColorBrush { get; set; }
        public string NCS { get; set; }
    }
}